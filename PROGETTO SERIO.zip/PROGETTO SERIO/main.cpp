//
//  main.cpp
//  main
//
//  Created by Marcello Cornali on 15/05/21.
//

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <fstream>
#include "Menu.h"
using namespace std;

int main()
{
    srand(time(NULL));
    Menu m;
    return 0;
}
